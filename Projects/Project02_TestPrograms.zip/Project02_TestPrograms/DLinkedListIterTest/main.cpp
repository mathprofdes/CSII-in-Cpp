#include <ctime>
#include <iostream>

#include "DLinkedList.h"

using namespace std;

template <class T> void displayHeadTail(DLinkedList<T> &);

template <class T> class Thing {
private:
  T *d;

public:
  Thing(T val = T()) {
    d = new T;
    *d = val;
  };
  ~Thing() { delete d; }
  Thing(const Thing &obj) {
    d = new T;
    *d = *(obj.d);
  };
  const Thing operator=(const Thing &right) {
    *d = *(right.d);
    return *this;
  }
  void set(T a) { *d = a; }
  T get() { return *d; }
  friend ostream &operator<<(ostream &out, Thing &t) {
    out << *t.d;
    return out;
  }
};

void div(string s = "") {
  cout << "\n" << s << "----------------------------------\n\n";
}

int main() {
  srand(time(0));
  DLinkedList<int> lst;

  div("Push back and delete tests ");

  lst.push_back(12);
  lst.push_back(4);
  lst.push_back(54);
  lst.push_back(10);

  lst.displayList();
  cout << endl;
  displayHeadTail(lst);

  lst.push_back(101);
  lst.push_back(17);
  lst.push_back(21);

  lst.displayList();
  cout << endl;
  displayHeadTail(lst);

  lst.deleteNode(12);

  lst.displayList();
  cout << endl;
  displayHeadTail(lst);

  lst.deleteNode(101);

  lst.displayList();
  cout << endl;
  displayHeadTail(lst);

  lst.deleteNode(1234);

  lst.displayList();
  cout << endl;
  displayHeadTail(lst);

  lst.deleteNode(21);

  lst.displayList();
  cout << endl;
  displayHeadTail(lst);

  lst.push_back(112);
  lst.push_back(14);
  lst.push_back(154);
  lst.push_back(110);

  lst.displayList();
  cout << endl;
  displayHeadTail(lst);

  div("Print reversed ");

  lst.displayList();
  cout << endl;
  lst.displayList(false, true);
  cout << endl;

  div("Insert Tests ");
  lst.clear();
  displayHeadTail(lst);

  lst.clear();
  lst.insertNode(45);
  lst.displayList();
  cout << endl;
  displayHeadTail(lst);

  lst.insertNode(21);
  lst.displayList();
  cout << endl;
  displayHeadTail(lst);

  lst.insertNode(57);
  lst.displayList();
  cout << endl;
  displayHeadTail(lst);

  for (int i = 0; i < 10; i++)
    lst.insertNode(rand() % 100);

  lst.displayList();
  cout << endl;
  displayHeadTail(lst);

  div("Push front tests ");

  lst.clear();
  lst.push_front(12);
  lst.displayList();
  cout << endl;
  displayHeadTail(lst);

  lst.push_front(15);
  lst.displayList();
  cout << endl;
  displayHeadTail(lst);

  lst.push_front(25);
  lst.displayList();
  cout << endl;
  displayHeadTail(lst);

  for (int i = 0; i < 10; i++)
    lst.push_front(rand() % 100);

  lst.displayList();
  cout << endl;
  displayHeadTail(lst);

  div("Pop front and back with indexing tests ");

  try {
    cout << lst.pop_front() << endl;
    lst.displayList();
    cout << endl;
    displayHeadTail(lst);

    cout << lst.pop_front() << endl;
    lst.displayList();
    cout << endl;
    displayHeadTail(lst);

    cout << lst.pop_front() << endl;
    lst.displayList();
    cout << endl;
    displayHeadTail(lst);

    cout << lst.pop_front() << endl;
    lst.displayList();
    cout << endl;
    displayHeadTail(lst);

    cout << lst.pop_back() << endl;
    lst.displayList();
    cout << endl;
    displayHeadTail(lst);

    cout << lst.pop_back() << endl;
    lst.displayList();
    cout << endl;
    displayHeadTail(lst);

    cout << lst.pop_back() << endl;
    lst.displayList();
    cout << endl;
    displayHeadTail(lst);

  } catch (string err) {
    cout << err << endl;
  }

  try {
    cout << lst[5] << endl;
    cout << lst[2] << endl;
    cout << lst[6] << endl;
    cout << lst[21] << endl;
  } catch (string err) {
    cout << err << endl;
  }

  lst.displayList();
  cout << endl;

  try {
    lst[5] = 17;
    lst[1] = 29;
    lst[3] = 11;
    lst[52] = 7;
  } catch (string err) {
    cout << err << endl;
  }

  lst.displayList();
  cout << endl;
  displayHeadTail(lst);

  try {
    lst.set(5, -17);
    lst.set(1, -29);
    lst.set(3, -11);
    lst.set(52, -7);
  } catch (string err) {
    cout << err << endl;
  }

  lst.displayList();
  cout << endl;
  displayHeadTail(lst);

  div("CC and = tests ");

  DLinkedList<int> L1;
  for (int i = 0; i < 5; i++)
    L1.push_back(rand() % 10000 + 1);

  DLinkedList<int> L2 = L1;
  DLinkedList<int> L3(L1);

  L1.displayList();
  cout << endl;
  L2.displayList();
  cout << endl;
  L3.displayList();
  cout << endl << endl;

  L1[3] = 1234567;
  L3[3] = 7654321;

  L1.displayList();
  cout << endl;
  L2.displayList();
  cout << endl;
  L3.displayList();
  cout << endl << endl;

  L3 = L2 = L1;

  L1.displayList();
  cout << endl;
  L2.displayList();
  cout << endl;
  L3.displayList();
  cout << endl << endl;

  L1[3] = 987654321;
  L2[1] = -25;

  L1.displayList();
  cout << endl;
  L2.displayList();
  cout << endl;
  L3.displayList();
  cout << endl << endl;

  L1 = L1;
  cout << L1 << endl;
  cout << endl;

  div("Reverse tests ");

  L2 = L1.reverse();
  cout << L1 << endl;
  cout << L2 << endl;
  cout << endl;

  L2.pop_front();
  L2.pop_back();
  cout << L1 << endl;
  cout << L2 << endl;
  cout << endl;

  div("Sort tests ");

  L2 = L1.sort();
  cout << L1 << endl;
  cout << L2 << endl;
  cout << endl;

  L1 = L1.sort();
  cout << L1 << endl;
  cout << endl;

  div("Iterator Tests ");

  cout << L1 << endl;
  DLinkedList<int>::iterator lstIter = L1.begin();

  for (DLinkedList<int>::iterator it = L1.begin(); it != L1.end(); it++)
    cout << *it << " ";
  cout << endl;

  lstIter += 2;
  *lstIter = 12345;

  for (DLinkedList<int>::iterator it = L1.begin(); it != L1.end(); it++)
    cout << *it << " ";
  cout << endl;

  // Even a range-based for loop works with this structure.
  for (auto element : L1)
    cout << element << " ";
  cout << endl;

  for (int element : L1)
    cout << element << " ";
  cout << endl;

  // Default CC and = work as well with the iterator, no need to overload.
  lstIter = L1.end();
  cout << *lstIter << endl;

  lstIter = L1.begin();
  lstIter += 3;
  DLinkedList<int>::iterator lstIter2(lstIter);
  cout << *lstIter2 << endl;
  lstIter2--;
  cout << *lstIter2 << endl;
  lstIter2 -= 2;
  cout << *lstIter2 << endl;
  lstIter2 -= 5;
  cout << *lstIter2 << endl;
  lstIter2 += 2;
  cout << *lstIter2 << endl;
  lstIter2 += 200;
  cout << *lstIter2 << endl;
  --lstIter2;
  cout << *lstIter2 << endl;
  --lstIter2;
  cout << *lstIter2 << endl;
  ++lstIter2;
  cout << *lstIter2 << endl;
  cout << *lstIter << endl;

  lstIter = L1.begin();
  lstIter2 = lstIter += 2;
  cout << *lstIter2 << endl;
  cout << *lstIter << endl;

  lstIter2 = lstIter++;
  cout << *lstIter2 << endl;
  cout << *lstIter << endl;

  lstIter2 = ++lstIter;
  cout << *lstIter2 << endl;
  cout << *lstIter << endl;

  lstIter2 = lstIter--;
  cout << *lstIter2 << endl;
  cout << *lstIter << endl;

  lstIter2 = --lstIter;
  cout << *lstIter2 << endl;
  cout << *lstIter << endl;

  L2 = L1;

  cout << L1 << endl;
  cout << L2 << endl;

  lstIter = L1.begin();
  lstIter2 = L2.begin();

  lstIter += 2;
  lstIter2 += 3;
  *lstIter = 23;
  *lstIter2 = 42;

  cout << L1 << endl;
  cout << L2 << endl;

  if (L1.find(23) != L1.end()) {
    cout << "23 found" << endl;
  } else {
    cout << "23 not found" << endl;
  }

  if (L1.find(123) != L1.end()) {
    cout << "123 found" << endl;
  } else {
    cout << "123 not found" << endl;
  }

  lstIter = L1.find(23);
  cout << *lstIter << endl;
  lstIter++;
  cout << *lstIter << endl;

  lstIter = L1.end() - 1;
  cout << *lstIter << endl;
  lstIter = L1.begin() + 2;
  cout << *lstIter << endl;

  DLinkedList<int *> L4;

  for (int i = 0; i < 10; i++) {
    int *nint = new int;
    *nint = rand() % 100;
    L4.push_back(nint);
  }

  for (DLinkedList<int *>::iterator it = L4.begin(); it != L4.end(); it++)
    cout << **it << " ";
  cout << endl;

  // Remove the new ints we created.
  for (DLinkedList<int *>::iterator it = L4.begin(); it != L4.end(); it++)
    delete *it;

  div("Iterator Insert Tests ");
  cout << L1 << endl;
  lstIter = L1.begin() + 3;
  L1.insert(lstIter, 12345);
  cout << L1 << endl;
  displayHeadTail(L1);
  L1.insert(L1.begin(), 54321);
  cout << L1 << endl;
  displayHeadTail(L1);
  L1.insert(L1.end(), 77777);
  cout << L1 << endl;
  displayHeadTail(L1);

  div("Iterator Remove Tests ");
  cout << L1 << endl;
  lstIter = L1.begin() + 2;
  L1.remove(lstIter);
  cout << L1 << endl;
  displayHeadTail(L1);
  L1.remove(L1.begin());
  cout << L1 << endl;
  displayHeadTail(L1);
  L1.remove(L1.end());
  cout << L1 << endl;
  displayHeadTail(L1);
  L1.remove(L1.end() - 1);
  cout << L1 << endl;
  displayHeadTail(L1);

  cout << L1.isEmpty() << endl;

  while (!L1.isEmpty()) {
    L1.remove(L1.begin());
    cout << L1 << endl;
    displayHeadTail(L1);
  }
  cout << L1.isEmpty() << endl;

  //  Go too far.
  L1.remove(L1.begin());
  cout << L1 << endl;
  cout << L1.isEmpty() << endl;

  DLinkedList<Thing<double>> Things;

  for (int i = 0; i < 10; i++) {
    double t = 1.0 * rand() / RAND_MAX;
    Thing<double> thing(t);
    Things.push_back(thing);
  }

  DLinkedList<Thing<double>>::iterator thingit;
  for (DLinkedList<Thing<double>>::iterator it = Things.begin();
       it != Things.end(); it++)
    cout << *it << " ";
  cout << endl;

  DLinkedList<Thing<double> *> PThings;
  DLinkedList<Thing<double> *>::iterator pthingit;
  for (int i = 0; i < 15; i++) {
    double t = 1.0 * rand() / RAND_MAX;
    Thing<double> *thing = new Thing<double>;
    thing->set(t);
    PThings.push_back(thing);
  }

  for (DLinkedList<Thing<double> *>::iterator it = PThings.begin();
       it != PThings.end(); it++)
    cout << it->get() << " ";
  cout << endl;

  for (auto element : PThings)
    cout << element->get() << " ";
  cout << endl;

  for (auto element : PThings)
    element->set(element->get() + 1);

  for (auto element : PThings)
    cout << element->get() << " ";
  cout << endl;

  // Delete the things created for the list.
  for (auto element : PThings)
    delete element;

  return 0;
}

template <class T> void displayHeadTail(DLinkedList<T> &L) {
  cout << "Head: ";
  try {
    cout << L.peekHead() << endl;
  } catch (string s) {
    cout << s << endl;
  }

  cout << "Tail: ";
  try {
    cout << L.peekTail() << endl;
  } catch (string s) {
    cout << s << endl;
  }
}
